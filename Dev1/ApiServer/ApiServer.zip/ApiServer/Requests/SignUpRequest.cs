﻿using System;

namespace ApiServer.Requests
{
    public class SignUpRequest
    
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}