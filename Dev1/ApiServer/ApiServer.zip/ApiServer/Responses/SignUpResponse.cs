﻿namespace ApiServer.Responses
{
    public class SignUpResponse
    {
        public string Status;
    }
}