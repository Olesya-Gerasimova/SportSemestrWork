﻿//using System;
//using Microsoft.AspNetCore.Authorization;

//namespace ApiServer.Requirements
//{
//    public class UserBlockedStatusRequirement : IAuthorizationRequirement
//    {
//        public bool IsBlocked { get; }
//        public UserBlockedStatusRequirement(bool isBlocked)
//        {
//            IsBlocked = isBlocked;
//        }

//    }
//}
